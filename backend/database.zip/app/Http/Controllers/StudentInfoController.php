<?php

namespace App\Http\Controllers;

use App\Models\Course;
use Illuminate\Http\Request;
use App\Models\Session;
use App\Models\Studentinfo;
use App\Models\Feedback;
use App\Models\NotifyAll;
use App\Models\Support;
use App\Models\Notify;
use App\Models\Register;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Redis;

class StudentInfoController extends Controller
{
    function formChecker(Request $request)
    {
        // session_start();

        // return session('key');

        $appid = '';
        $info = Session::all()->last();
        $res = DB::table('applications')
            ->where('rid', $info['rid'])
            ->get();

        if (count($res)) {
            $res = DB::table('register')->join('applications', 'register.rid', '=', 'applications.rid')->select('register.rid', 'register.firstname', 'register.lastname', 'register.email', 'applications.*')->where('register.rid', $info['rid'])->get();
            return ['status' => 'filled', 'res' => $res];
        } else {
            $reg = DB::table('register')
                ->where('rid', $info['rid'])
                ->get();
            $app = Studentinfo::all()->last();
            if (!$app)
                $appid = 'BCKAPPid-101';
            else {
                $s1 = $app->aid;
                list($part1, $part2) = explode('-', $s1);
                $x = 1 + (int) $part2;
                $appid = 'BCKAPPid-' . (string)$x;
            }

            return ['status' => 'notfilled', 'res' => $reg, 'aid' => $appid];
        }
    }
    function  application(Request $req)
    {
        //return 'this is me ';
        //return $req->input();
        $info = Session::all()->last();
        $studinfo = new Studentinfo();

        $studinfo->rid = $info['rid'];
        $studinfo->course = $req->input('course');
        $studinfo->aid = $req->input('aid');
        $studinfo->fathername = $req->input('fathername');
        $studinfo->gender = $req->input('gender');
        $date = $req->input('dob');
        $studinfo->dob = date('Y-m-d', strtotime($date));

        $studinfo->phone = $req->input('phone');
        $studinfo->pumark = $req->input('pumark');
        $studinfo->address = $req->input('address');
        $studinfo->photo = ltrim($req->file('photo')->store('public'), 'public/');
        $studinfo->pumarkscard = ltrim($req->file('pumarkscard')->store('public'), 'public/');
        $studinfo->status = 'pending';


        $studinfo->save();
        return ['status' => 'infosaved'];
    }
    function editApplication(Request $request)
    {
        //return $request->input();
        $info = Session::all()->last();

        if ($request->has('photo')) {

            $file = Studentinfo::select('photo')->where('rid', $info['rid'])->get();

            File::delete(' storage/' . $file[0]['photo']);

            $photo = ltrim($request->file('photo')->store('public'), 'public/');
            $res = Studentinfo::where('rid', $info['rid'])->update(['photo' => $photo]);
            if ($res)
                return 'saved';
            else
                return 'notsaved';
        }
        //-----------------------------------------------------------------------------
        if ($request->has('pumarkscard')) {
            $file = Studentinfo::select('pumarkscard')->where('rid', $info['rid'])->get();

            File::delete('storage/' . $file[0]['pumarkscard']);
            $pumarkscard = ltrim($request->file('pumarkscard')->store('public'), 'public/');
            $res = Studentinfo::where('rid', $info['rid'])->update(['pumarkscard' => $pumarkscard]);
            if ($res)
                return 'saved';
            else
                return 'notsaved';
        }
        //---------------------------------------------------------------------------------------------------
        $fathername = $request->input('fathername');
        $dob = $request->input('dob');
        $course = $request->input('course');
        $pumark = $request->input('pumark');
        $address = $request->input('address');
        $phone = $request->input('phone');
        $gender = $request->input('gender');
        $arr = ['fathername' => $fathername, 'dob' => $dob, 'course' => $course, 'pumark' => $pumark, 'address' => $address, 'gender' => $gender, 'phone' => $phone];
        $res = Studentinfo::where('rid', $info['rid'])->update($arr);
        if ($res)
            return 'saved';
        else
            return 'notsaved';
    }
    function statuscheck(Request $request)
    {

        $info = Session::all()->last();
        // $res = D::table('applications')
        //     ->where('rid', $info['id'])->select('status')
        //     ->get();
        $res = Studentinfo::select('status')->where('rid', $info['rid'])->get();
        //return json_decode($res["status"]);
        //return $res;

        if (count($res))
            return  ['result' => $res[0]['status']];
        else
            return ['result' => 'notfilled'];
    }
    function notifications(Request $request)
    {
        $info = Session::all()->last();

        $specific = Notify::select()->where('rid', $info['rid'])->get();
        $all = NotifyAll::all();
        if (!count($specific) && !count($all))
            return ['status' => 'nodata'];
        return ['specific' => $specific, 'all' => $all];
    }
    function feedback(Request $req)
    {

        $info = Session::all()->last();
        $feed = new Feedback();
        $feed->rid = $info['rid'];
        $feed->rating = $req->input('rating');
        $feed->feedback = $req->input('feedback');
        $feed->save();
    }
    function feedbackcheck(Request $request)
    {
        $info = Session::all()->last();

        $res = Feedback::all()->where('rid', $info['rid']);
        // $res = DB::table('feedbacks')
        //     ->where('rid', $info['id'])
        //     ->get();

        if (count($res))
            return ['status' => true];
        else
            return ['status' => false];
    }
    function supportwid(Request $request)
    {
        $info = Session::all()->last();
        $res = DB::table('supports')
            ->where('rid', $info['rid'])
            ->get();

        $res = json_decode($res);
        //I had some problem with this $res ....
        if (!count($res))
            return ['result' => 'empty'];

        return ['result' => $res];
    }
    function sendrequesttosupport(Request $request)
    {
        $info = Session::all()->last();
        $sup = new Support();
        $sup->rid = $info['rid'];
        $sup->request = $request->input('request');
        $sup->save();

        $info = Session::all()->last();
        $res = DB::table('supports')
            ->where('rid', $info['rid'])
            ->get();

        $res = json_decode($res);

        if (!count($res))
            return ['result' => 'empty'];

        return ['result' => $res];
    }
    function onlycoursename()
    {
        $res = Course::get(['course']);
        if (count($res))
            return $res;
        else
            return [['course' => null]];
    }
    function getname()
    {
        $info = Session::all()->last();

        $res = Register::all()->where('rid', $info['rid'])->last();

        return ['result' => $res];
    }
    function setname(Request $request)
    {
        $info = Session::all()->last();
        $rid = $info['rid'];
        $firstname = $request->input('firstname');
        $lastname = $request->input('lastname');

        $ary = ['firstname' => $firstname, 'lastname' => $lastname];

        $res = Register::where('rid', $rid)->update($ary);
        if ($res)
            return ['status' => 'infosaved'];
    }
    function changepassword(Request $request)
    {
        $info = Session::all()->last();
        $rid = $info['rid'];
        $password = Hash::make($request->input('password'));
        $ary = ['password' => $password];
        $res = Register::where('rid', $rid)->update($ary);
        if ($res)
            return ['status' => 'infosaved'];
    }
}
