<?php

namespace App\Http\Controllers;
use App\Models\Session;

use Illuminate\Http\Request;

class SessionController extends Controller
{
    function sessionstart(Request $request){
        //return $request;
       $session=new Session();
        $session->rid=$request->input('id');
        $session->email=$request->input('email');
        $session->cookie='';
        $session->save();
        return 'session saved ';
   }
   function sessionend(Request $request){
       Session::truncate();
       return 'session ended';

   }
   function mycookcheck(Request $req){
        return Session::select('rid')->where('cookie',$req->input('mycookie'))->get();

   }
}
