<?php

namespace App\Http\Controllers;

use App\Models\Register;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Crypt;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Session;


class RegisterController extends Controller
{

    function register(Request $request)
    {
        // return $request->input();
        if ($request->input('email') == 'admin@12')
            return json_encode(['status' => 'exists']);
        $user = new Register();
        $res = DB::table('register')->first();
        if (empty($res)) {

            $user->rid = 100000;
            $user->firstname = $request->input('firstname');
            $user->lastname = $request->input('lastname');

            $user->email = $request->input('email');
            $user->password = Hash::make($request->input('password'));
            $user->save();
            return json_encode(['status' => 'saved']);
        } else {

            $res = DB::table('register')
                ->where('email', $request->input('email'))
                ->get();
            if (count($res)) {
                return json_encode(['status' => 'exists']);
            } else {
                $user->firstname = $request->input('firstname');
                $user->lastname = $request->input('lastname');
                $user->email = $request->input('email');
                $user->password = Hash::make($request->input('password'));
                $user->save();
                return json_encode(['status' => 'saved']);
            }
        }
    }
    function login(Request $request)
    {
        //return json_encode($request->header());
        $email = $request->input('email');
        $password = $request->input('password');
        //return [$email,$password];
        if ($email == 'admin@12' && $password == 'admin@12')
            return ['status' => 'admin'];
        $res = DB::table('register')->where('email', $email)->first();
      
        if (!empty($res)) {
            if (Hash::check($password, $res->password)) {
                $token = sha1(mt_rand(1, 90000) . 'SALT');
                // $mycookie=cookie('mycookie',$token,10);
            //    $sesres= Session::all()->where('rid',$res->rid);
            //    // return $sesres;
            //    if(count($sesres))
            //         Session::where('rid',$sesres[0]->rid)->delete();

                session_start();
                $request->session()->put('key', $res);
                // return session('key');
                $session=new Session();
                $session->rid=$res->rid;
                $session->email=$res->email;
                $session->cookie=$token;
                $session->save();
                

                return response(['status' => 'student', 'info' => $res, 'token' => $token]);
            } else {
                return ['status' => 'passerror'];
            }
        } else
            return ['status' => 'notfound'];
    }
}
